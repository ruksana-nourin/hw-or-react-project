<?php
require_once "../model/user.class.php";
function getUsers()
{
    // echo "getAll function called successfully";
    echo json_encode(User ::getAll());
}

function getUserById($id){
    // echo "getUserById function called successfully";
    echo json_encode(User ::getById($id));
}