<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Handle browser preflight request

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(204);
    exit;
}
require_once "../config/db.php";

// require_once "../model/user.class.php";

// Load all model files
foreach (glob("../model/*.class.php") as $modelFile) {
    require_once $modelFile;
}

// Load all API files
foreach (glob("*-api.php") as $apiFile) {
    require_once $apiFile;
}

if (isset($_GET['endpoint'])) {
    $endpoint = $_GET['endpoint'];
    $method = $_SERVER['REQUEST_METHOD'];

    //user endpoint
    // GET    users
    // GET    user-details
    // POST   user-create
    // PUT    user-update
    // DELETE user-delete

    if ($endpoint == 'users'  && $method == 'GET') {
        // echo "users api";
        getUsers();
    } elseif ($endpoint == 'user-details'  && $method == 'GET') {
        // echo "user-details api";
        $id = $_GET['id'];
        getUserById($id);
    } elseif ($endpoint == 'user-create'  && $method == 'POST') {
        echo "user-create api";
    } elseif ($endpoint == 'user-update'  && $method == 'PUT') {
        echo "user-update api";
    } elseif ($endpoint == 'user-delete'  && $method == 'DELETE') {
        echo "user-delete api";
    }
} else {
    http_response_code(404);
    echo "No endpoint found";
}
