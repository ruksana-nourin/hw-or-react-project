<?php

// require_once "../config/db.php";

// echo "USER CLASS LOADED<br>";
class User
{

    public $id;
    public $name;
    public $email;
    public $phone;
    public $role_id;
    public $status_id;
    public $department_id;
    public $created_at;

    private $password;

    public function __construct(
        $id = null,
        $name = "",
        $email = "",
        $phone = "",
        $role_id = null,
        $status_id = null,
        $department_id = null,
        $created_at = "",
        $password = ""
    ) {

        $this->id = $id;
        $this->name = $name;
        $this->email = $email;
        $this->phone = $phone;
        $this->role_id = $role_id;
        $this->status_id = $status_id;
        $this->department_id = $department_id;
        $this->created_at = $created_at;

        if ($password !== "") {
            $this->password = password_hash($password, PASSWORD_DEFAULT);
        }
    }

    public static function getAll()
    {
        // echo "function called Succesfully";
        global $db;

        $query = "SELECT 
                    u.id,
                    u.name,
                    u.email,
                    u.phone,
                    u.role_id,
                    r.name AS role,
                    u.status_id,
                    s.name AS status,
                    u.department_id,
                    d.name AS department,
                    u.created_at
                  FROM users AS u, 
                       roles AS r,
                       statuses AS s,
                       departments AS d
                  WHERE u.role_id = r.id
                    AND u.status_id = s.id
                    AND u.department_id = d.id
                  ORDER BY u.id DESC";

        $result = $db->query($query);

        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public static function getById($id)
    {

        global $db;
        $query = "SELECT 
                    u.id,
                    u.name,
                    u.email,
                    u.phone,
                    u.role_id,
                    r.name AS role,
                    u.status_id,
                    s.name AS status,
                    u.department_id,
                    d.name AS department,
                    u.created_at,
                    u.address,
                    u.last_login
                  FROM users AS u, 
                       roles AS r,
                       statuses AS s,
                       departments AS d
                  WHERE u.role_id = r.id
                    AND u.status_id = s.id
                    AND u.department_id = d.id
                    AND u.id = $id";
        $result = $db->query($query);
        return $result->fetch_assoc();
    }
}
